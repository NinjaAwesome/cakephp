<?php

/* D:\xampp\htdocs\collabthem/plugins/BackEnd/src\Template\Bake\Element\Controller/changeFlag.twig */
class __TwigTemplate_518e14e341f1ce4e10313be91902d8f9187ac97b0e090de79fe9222d3cfec520 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa = $this->env->getExtension("WyriHaximus\\TwigView\\Lib\\Twig\\Extension\\Profiler");
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->enter($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Element\\Controller/changeFlag.twig"));

        // line 1
        echo "  /**
     * ChangeFlag method
     *
     * @param string|null &id flag id.
     * @param string|null &id field those update table field.
     * @param string|null &status Admin status.
     * @return \\Cake\\Http\\Response|null Redirects to index.
     * @throws \\Cake\\Datasource\\Exception\\RecordNotFoundException When record not found.
     */
    public function changeFlag()
    {
        if (\$this->request->is('ajax') && \$this->request->getData('id')) {
            \$status = \$this->";
        // line 13
        echo twig_escape_filter($this->env, ($context["currentModelName"] ?? null), "html", null, true);
        echo "->newEntity();
            \$field = \$this->request->getData('field');
            \$status->id = \$this->request->getData('id');
            \$status->\$field = \$this->request->getData('status');
            if (\$this->";
        // line 17
        echo twig_escape_filter($this->env, ($context["currentModelName"] ?? null), "html", null, true);
        echo "->save(\$status)) {
                \$msg = \$this->request->getData(\$field) == 1 ? __(\"Your {\$field} has activated\") : __(\"Your {\$field} has deactivated\");
                \$response = [\"success\" => true, \"err_msg\" => \$msg];
            } else {
                \$response = [\"success\" => false, \"err_msg\" => __(\"Your Process faild. please try again!!\")];
            }
            \$this->set([
                'success' => \$response['success'],
                'responce' => 200,
                'message' => \$response['err_msg'],
                '_jsonOptions' => JSON_FORCE_OBJECT,
                '_serialize' => ['success', 'responce', 'message']
            ]);
        }
        
    }
";
        
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->leave($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof);

    }

    public function getTemplateName()
    {
        return "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Element\\Controller/changeFlag.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 17,  36 => 13,  22 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("  /**
     * ChangeFlag method
     *
     * @param string|null &id flag id.
     * @param string|null &id field those update table field.
     * @param string|null &status Admin status.
     * @return \\Cake\\Http\\Response|null Redirects to index.
     * @throws \\Cake\\Datasource\\Exception\\RecordNotFoundException When record not found.
     */
    public function changeFlag()
    {
        if (\$this->request->is('ajax') && \$this->request->getData('id')) {
            \$status = \$this->{{ currentModelName }}->newEntity();
            \$field = \$this->request->getData('field');
            \$status->id = \$this->request->getData('id');
            \$status->\$field = \$this->request->getData('status');
            if (\$this->{{ currentModelName }}->save(\$status)) {
                \$msg = \$this->request->getData(\$field) == 1 ? __(\"Your {\$field} has activated\") : __(\"Your {\$field} has deactivated\");
                \$response = [\"success\" => true, \"err_msg\" => \$msg];
            } else {
                \$response = [\"success\" => false, \"err_msg\" => __(\"Your Process faild. please try again!!\")];
            }
            \$this->set([
                'success' => \$response['success'],
                'responce' => 200,
                'message' => \$response['err_msg'],
                '_jsonOptions' => JSON_FORCE_OBJECT,
                '_serialize' => ['success', 'responce', 'message']
            ]);
        }
        
    }
", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Element\\Controller/changeFlag.twig", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Element\\Controller/changeFlag.twig");
    }
}
