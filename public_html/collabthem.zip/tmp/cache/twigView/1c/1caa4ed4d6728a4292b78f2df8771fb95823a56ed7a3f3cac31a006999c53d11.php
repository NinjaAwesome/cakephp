<?php

/* D:\xampp\htdocs\collabthem/plugins/BackEnd/src\Template\Bake\Template\index.twig */
class __TwigTemplate_fe2f76126ea59d2003c01543d38168840d8052425f5a2108929accba851d418b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa = $this->env->getExtension("WyriHaximus\\TwigView\\Lib\\Twig\\Extension\\Profiler");
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->enter($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Template\\index.twig"));

        // line 18
        echo "<?php
/**
* @var \\";
        // line 20
        echo twig_escape_filter($this->env, ($context["namespace"] ?? null), "html", null, true);
        echo "\\View\\AppView \$this
* @var \\";
        // line 21
        echo twig_escape_filter($this->env, ($context["entityClass"] ?? null), "html", null, true);
        echo "[]|\\Cake\\Collection\\CollectionInterface \$";
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "
*/
?>
";
        // line 24
        $context["fields"] = $this->getAttribute(($context["Bake"] ?? null), "filterFields", array(0 => ($context["fields"] ?? null), 1 => ($context["schema"] ?? null), 2 => ($context["modelObject"] ?? null), 3 => ($context["indexColumns"] ?? null), 4 => array(0 => "binary", 1 => "text")), "method");
        // line 25
        echo "<section class=\"content-header\">
    <h1>
        <?= __('Manage ";
        // line 27
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "') ?>  
        <small><?php echo __('Here you can manage the ";
        // line 28
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["pluralHumanName"] ?? null)), "html", null, true);
        echo "'); ?></small>
    </h1>
    <?= \$this->element('breadcrumb') ?>
</section>
<section class=\"content\" data-table=\"";
        // line 32
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "\">   
    <div class=\"row ";
        // line 33
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "\">
        <div class=\"col-md-12\">
            <div class=\"box box-info\">
                <h3></h3>

                <div class=\"box-header\">
                    <h3 class=\"box-title\"><span class=\"caption-subject font-green bold uppercase\">List <?= __('";
        // line 39
        echo twig_escape_filter($this->env, ($context["pluralHumanName"] ?? null), "html", null, true);
        echo "') ?></span></h3>
                    <div class=\"box-tools\">
                        <?= \$this->Html->link(\"<i class=\\\"fa fa-plus\\\"></i> \" . __('New ";
        // line 41
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "'), [\"action\" => \"add\"], [\"class\" => \"btn btn-success btn-flat\", \"escape\" => false]) ?>
                    </div>
                </div><!-- /.box-header -->

    <div class=\"box-body table-responsive\">    
        <table class=\"table table-hover table-striped\">
            <thead>
            <tr>
                <th>#</th>
";
        // line 50
        $context["cols"] = 2;
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["fields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 52
            if (!twig_in_filter($context["field"], array(0 => "id", 1 => "modified", 2 => "password"))) {
                // line 53
                echo "                <th scope=\"col\"><?= \$this->Paginator->sort('";
                echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                echo "') ?></th>
";
                // line 54
                $context["cols"] = (($context["cols"] ?? null) + 1);
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "                <th scope=\"col\" class=\"actions\"><?= __('Actions') ?></th>
            </tr>
        </thead>
        <tbody>
                <?php if (!empty(\$";
        // line 61
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "->toArray())): 
                \$i = (((\$this->Paginator->param('page') - 1) * \$this->Paginator->param('perPage')) + 1);
                foreach (\$";
        // line 63
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo " as \$";
        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
        echo "): ?>
                <tr>
                    <td><?= \$this->Number->format(\$i) ?>.</td>
";
        // line 66
        $context["break"] = false;
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["fields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 68
            if (!twig_in_filter($context["field"], array(0 => "id", 1 => "modified", 2 => "password"))) {
                // line 69
                echo "    ";
                $context["isKey"] = false;
                // line 70
                if ($this->getAttribute(($context["associations"] ?? null), "BelongsTo", array())) {
                    // line 71
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["associations"] ?? null), "BelongsTo", array()));
                    foreach ($context['_seq'] as $context["alias"] => $context["details"]) {
                        if (($context["field"] == $this->getAttribute($context["details"], "foreignKey", array()))) {
                            // line 72
                            echo "    ";
                            $context["isKey"] = true;
                            // line 73
                            echo "        <td><?= \$";
                            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                            echo "->has('";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "property", array()), "html", null, true);
                            echo "') ? \$this->Html->link(\$";
                            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "property", array()), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "displayField", array()), "html", null, true);
                            echo ", ['controller' => '";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "controller", array()), "html", null, true);
                            echo "', 'action' => 'view', \$";
                            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "property", array()), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["details"], "primaryKey", array()), 0, array(), "array"), "html", null, true);
                            echo "]) : '' ?>
        </td>
";
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['alias'], $context['details'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                }
                // line 77
                if ( !(($context["isKey"] ?? null) === true)) {
                    // line 78
                    if ((($context["field"] == "status") || ($context["field"] == "is_verified"))) {
                        // line 79
                        $context["isKey"] = true;
                        // line 80
                        echo "            <td>
                    <?= \$this->Form->checkbox('";
                        // line 81
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['checked' => \$";
                        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                        echo "->";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo " == 1 ? true : false, 'class' => 'switch-status change-request', 'data-id' => \$";
                        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                        echo "->id, 'data-field' => '";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', 'data-url' => \$this->Url->build(['action'=>'changeFlag']), 'data-size' => 'mini']); ?>
                   
            </td>
";
                    }
                }
                // line 86
                if ( !(($context["isKey"] ?? null) === true)) {
                    // line 87
                    if (($context["field"] == "created")) {
                        // line 88
                        echo "    ";
                        $context["isKey"] = true;
                        // line 89
                        echo "    <td>
        <?php if (\$";
                        // line 90
                        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                        echo "->";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo " != \"\") {
                echo \$";
                        // line 91
                        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                        echo "->";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "->format(\$ConfigSettings['ADMIN_DATE_TIME_FORMAT']);
                }
                ?>
    </td>
";
                    }
                }
                // line 97
                if ( !(($context["isKey"] ?? null) === true)) {
                    // line 98
                    $context["columnData"] = $this->getAttribute(($context["Bake"] ?? null), "columnData", array(0 => $context["field"], 1 => ($context["schema"] ?? null)), "method");
                    // line 99
                    if (!twig_in_filter($this->getAttribute(($context["columnData"] ?? null), "type", array()), array(0 => "integer", 1 => "float", 2 => "decimal", 3 => "biginteger", 4 => "smallinteger", 5 => "tinyinteger"))) {
                        // line 100
                        if (twig_in_filter($this->getAttribute(($context["columnData"] ?? null), "type", array()), array(0 => "boolean"))) {
                            // line 101
                            echo "        <td>
            <?php if (\$";
                            // line 102
                            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                            echo " == 1) {
                    echo \"Yes\";
                }else{
                    echo \"No\";
                }
            ?>
        </td>
";
                        } else {
                            // line 110
                            echo "            <td><?= h(\$";
                            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                            echo "->";
                            echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                            echo ") ?></td>
";
                        }
                    } else {
                        // line 113
                        echo "            <td><?= \$this->Number->format(\$";
                        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
                        echo "->";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo ") ?></td>
";
                    }
                }
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 118
        $context["pk"] = ((("\$" . ($context["singularVar"] ?? null)) . "->") . $this->getAttribute(($context["primaryKey"] ?? null), 0, array(), "array"));
        // line 119
        echo "                    <td class=\"actions\">
                                        <?= \$this->Html->link(\"<i class=\\\"fa fa-fw fa-eye\\\"></i>\", ['action' => 'view', ";
        // line 120
        echo ($context["pk"] ?? null);
        echo "],['class' => 'btn btn-warning btn-sm btn-flat', 'escape' => false,'data-toggle'=>'tooltip','alt'=>__('View ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "'),'title'=>__('View ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "')]) ?>
                                        <?= \$this->Html->link(\"<i class=\\\"fa fa-edit\\\"></i>\", ['action' => 'edit', ";
        // line 121
        echo ($context["pk"] ?? null);
        echo "], ['class' => 'btn btn-primary btn-sm btn-flat', 'escape' => false,'data-toggle'=>'tooltip','alt'=>__('Edit ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "'),'title'=>__('Edit ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "')]) ?>
                                        <?= \$this->Form->postLink(\"<i class=\\\"fa fa-trash\\\"></i>\", ['action' => 'delete', ";
        // line 122
        echo ($context["pk"] ?? null);
        echo "], ['onClick' => 'confirmDelete(this, \\''.";
        echo ($context["pk"] ?? null);
        echo ".'\\')','class' => 'btn btn-danger btn-sm btn-flat','data-toggle'=>'tooltip', 'escape' => false,'alt'=>__('Delete ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "'),'title'=>__('Delete ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "')]) ?>
                                </td>
                            </tr>
                            <?php \$i++; endforeach; ?>
                            <?php else: ?>
                            <tr> <td colspan='";
        // line 127
        echo twig_escape_filter($this->env, ($context["cols"] ?? null), "html", null, true);
        echo "' align='center' class=\"tbodyNotFound\" style=\"text-align:center;\"> <strong>Record Not Available</strong> </td> </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>            

                <div class=\"box-footer clearfix\">
                    <?php echo \$this->element('pagination'); ?>
                </div>            

            </div>
        </div>
    </div>
</section>";
        
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->leave($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof);

    }

    public function getTemplateName()
    {
        return "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Template\\index.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  307 => 127,  293 => 122,  285 => 121,  277 => 120,  274 => 119,  272 => 118,  258 => 113,  249 => 110,  236 => 102,  233 => 101,  231 => 100,  229 => 99,  227 => 98,  225 => 97,  214 => 91,  208 => 90,  205 => 89,  202 => 88,  200 => 87,  198 => 86,  182 => 81,  179 => 80,  177 => 79,  175 => 78,  173 => 77,  145 => 73,  142 => 72,  137 => 71,  135 => 70,  132 => 69,  130 => 68,  126 => 67,  124 => 66,  116 => 63,  111 => 61,  105 => 57,  98 => 54,  93 => 53,  91 => 52,  87 => 51,  85 => 50,  73 => 41,  68 => 39,  59 => 33,  55 => 32,  48 => 28,  44 => 27,  40 => 25,  38 => 24,  30 => 21,  26 => 20,  22 => 18,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @author        Hanuman Yadav
 * @author        Hanuman yadav <hanumanprasad.yadav@dotsquares.com>
 * @copyright     2018-19 The Dotsquares Cakephp Team (https://www.dotsquares.com)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         2.0.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
#}
<?php
/**
* @var \\{{ namespace }}\\View\\AppView \$this
* @var \\{{ entityClass }}[]|\\Cake\\Collection\\CollectionInterface \${{ pluralVar }}
*/
?>
{% set fields = Bake.filterFields(fields, schema, modelObject, indexColumns, ['binary', 'text']) %}
<section class=\"content-header\">
    <h1>
        <?= __('Manage {{ singularHumanName }}') ?>  
        <small><?php echo __('Here you can manage the {{ pluralHumanName|lower }}'); ?></small>
    </h1>
    <?= \$this->element('breadcrumb') ?>
</section>
<section class=\"content\" data-table=\"{{ pluralVar }}\">   
    <div class=\"row {{ pluralVar }}\">
        <div class=\"col-md-12\">
            <div class=\"box box-info\">
                <h3></h3>

                <div class=\"box-header\">
                    <h3 class=\"box-title\"><span class=\"caption-subject font-green bold uppercase\">List <?= __('{{ pluralHumanName }}') ?></span></h3>
                    <div class=\"box-tools\">
                        <?= \$this->Html->link(\"<i class=\\\"fa fa-plus\\\"></i> \" . __('New {{ singularHumanName }}'), [\"action\" => \"add\"], [\"class\" => \"btn btn-success btn-flat\", \"escape\" => false]) ?>
                    </div>
                </div><!-- /.box-header -->

    <div class=\"box-body table-responsive\">    
        <table class=\"table table-hover table-striped\">
            <thead>
            <tr>
                <th>#</th>
{% set cols = 2 %}
{% for field in fields %}
{% if field not in ['id', 'modified', 'password'] %}
                <th scope=\"col\"><?= \$this->Paginator->sort('{{ field }}') ?></th>
{% set cols = cols + 1 %}
{% endif %}
{% endfor %}
                <th scope=\"col\" class=\"actions\"><?= __('Actions') ?></th>
            </tr>
        </thead>
        <tbody>
                <?php if (!empty(\${{ pluralVar }}->toArray())): 
                \$i = (((\$this->Paginator->param('page') - 1) * \$this->Paginator->param('perPage')) + 1);
                foreach (\${{ pluralVar }} as \${{ singularVar }}): ?>
                <tr>
                    <td><?= \$this->Number->format(\$i) ?>.</td>
{% set break = false %}
{% for field in fields %}
{% if field not in ['id', 'modified', 'password'] %}
    {% set isKey = false %}
{% if associations.BelongsTo %}
{% for alias, details in associations.BelongsTo if field == details.foreignKey %}
    {% set isKey = true %}
        <td><?= \${{ singularVar }}->has('{{ details.property }}') ? \$this->Html->link(\${{ singularVar }}->{{ details.property }}->{{ details.displayField }}, ['controller' => '{{ details.controller }}', 'action' => 'view', \${{ singularVar }}->{{ details.property }}->{{ details.primaryKey[0] }}]) : '' ?>
        </td>
{% endfor %}
{% endif %}
{% if isKey is not same as(true) %}
{% if (field == 'status') or (field == 'is_verified') %}
{% set isKey = true %}
            <td>
                    <?= \$this->Form->checkbox('{{ field }}', ['checked' => \${{ singularVar }}->{{ field }} == 1 ? true : false, 'class' => 'switch-status change-request', 'data-id' => \${{ singularVar }}->id, 'data-field' => '{{ field }}', 'data-url' => \$this->Url->build(['action'=>'changeFlag']), 'data-size' => 'mini']); ?>
                   
            </td>
{% endif %}
{% endif %}
{% if isKey is not same as(true) %}
{% if field == 'created' %}
    {% set isKey = true %}
    <td>
        <?php if (\${{ singularVar }}->{{ field }} != \"\") {
                echo \${{ singularVar }}->{{ field }}->format(\$ConfigSettings['ADMIN_DATE_TIME_FORMAT']);
                }
                ?>
    </td>
{% endif %}
{% endif %}
{% if isKey is not same as(true) %}
{% set columnData = Bake.columnData(field, schema) %}
{% if columnData.type not in ['integer', 'float', 'decimal', 'biginteger', 'smallinteger', 'tinyinteger'] %}
{% if columnData.type in ['boolean'] %}
        <td>
            <?php if (\${{ singularVar }}->{{ field }} == 1) {
                    echo \"Yes\";
                }else{
                    echo \"No\";
                }
            ?>
        </td>
{% else %}
            <td><?= h(\${{ singularVar }}->{{ field }}) ?></td>
{% endif %}
{% else %}
            <td><?= \$this->Number->format(\${{ singularVar }}->{{ field }}) ?></td>
{% endif %}
{% endif %}
{% endif %}
{% endfor %}
{% set pk = '\$' ~ singularVar ~ '->' ~ primaryKey[0] %}
                    <td class=\"actions\">
                                        <?= \$this->Html->link(\"<i class=\\\"fa fa-fw fa-eye\\\"></i>\", ['action' => 'view', {{ pk|raw }}],['class' => 'btn btn-warning btn-sm btn-flat', 'escape' => false,'data-toggle'=>'tooltip','alt'=>__('View {{ singularHumanName|lower }}'),'title'=>__('View {{ singularHumanName|lower }}')]) ?>
                                        <?= \$this->Html->link(\"<i class=\\\"fa fa-edit\\\"></i>\", ['action' => 'edit', {{ pk|raw }}], ['class' => 'btn btn-primary btn-sm btn-flat', 'escape' => false,'data-toggle'=>'tooltip','alt'=>__('Edit {{ singularHumanName|lower }}'),'title'=>__('Edit {{ singularHumanName|lower }}')]) ?>
                                        <?= \$this->Form->postLink(\"<i class=\\\"fa fa-trash\\\"></i>\", ['action' => 'delete', {{ pk|raw }}], ['onClick' => 'confirmDelete(this, \\''.{{ pk|raw }}.'\\')','class' => 'btn btn-danger btn-sm btn-flat','data-toggle'=>'tooltip', 'escape' => false,'alt'=>__('Delete {{ singularHumanName|lower }}'),'title'=>__('Delete {{ singularHumanName|lower }}')]) ?>
                                </td>
                            </tr>
                            <?php \$i++; endforeach; ?>
                            <?php else: ?>
                            <tr> <td colspan='{{ cols }}' align='center' class=\"tbodyNotFound\" style=\"text-align:center;\"> <strong>Record Not Available</strong> </td> </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>            

                <div class=\"box-footer clearfix\">
                    <?php echo \$this->element('pagination'); ?>
                </div>            

            </div>
        </div>
    </div>
</section>", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Template\\index.twig", "D:\\xampp\\htdocs\\collabthem/plugins/BackEnd/src\\Template\\Bake\\Template\\index.twig");
    }
}
