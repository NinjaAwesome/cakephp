<?php
namespace App\Test\TestCase\Mailer;

use App\Mailer\ManuMailer;
use Cake\TestSuite\TestCase;

/**
 * App\Mailer\ManuMailer Test Case
 */
class ManuMailerTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Mailer\ManuMailer
     */
    public $Manu;

    /**
     * Test welcome method
     *
     * @return void
     */
    public function testWelcome()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test adminForgot method
     *
     * @return void
     */
    public function testAdminForgot()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test forgot method
     *
     * @return void
     */
    public function testForgot()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test contactUs method
     *
     * @return void
     */
    public function testContactUs()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test sendEmails method
     *
     * @return void
     */
    public function testSendEmails()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test setEmailConfig method
     *
     * @return void
     */
    public function testSetEmailConfig()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildMessage method
     *
     * @return void
     */
    public function testBuildMessage()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
