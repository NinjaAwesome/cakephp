
/************Main**Top*Menu******************************/


$(function () {
    var html = $('html, body'),
            navContainer = $('.nav-container'),
            navToggle = $('.nav-toggle'),
            navDropdownToggle = $('.has-dropdown');

    // Nav toggle
    navToggle.on('click', function (e) {
        var $this = $(this);
        e.preventDefault();
        $this.toggleClass('is-active');
        navContainer.toggleClass('is-visible');
        html.toggleClass('nav-open');
    });

    // Nav dropdown toggle
    navDropdownToggle.on('click', function () {
        var $this = $(this);
        $this.toggleClass('is-active').children('ul').toggleClass('is-visible');
    });

    // Prevent click events from firing on children of navDropdownToggle
    navDropdownToggle.on('click', '*', function (e) {
        e.stopPropagation();
    });
});


/*********************Section**************************/






/**************header***Fix***Start********************/

$(window).scroll(function () {
    var scroll = $(window).scrollTop();

    if (scroll >= 110) {
        $(".header").addClass("header-sticky");
    } else {
        $(".header").removeClass("header-sticky");



    }
});


$(function () {
    var div = $('.sort-menu');
    $('.sortBtn').click(function () {
        div.fadeToggle(200);
        css.width == 0;
    });
});

function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).val()).select();
    document.execCommand("copy");
    $temp.remove();
}