/*global Switchery:true*/ // Meteor creates a file-scope global for exporting. This comment prevents a potential JSHint warning.
Switchery = window.Switchery;
delete window.Switchery;